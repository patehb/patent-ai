# Patent AI

This is the base structure for Patent AI.